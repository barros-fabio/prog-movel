# Sensores_REA
Recursos educacionais para o ensino de interação com sensores usando a plataforma Android
