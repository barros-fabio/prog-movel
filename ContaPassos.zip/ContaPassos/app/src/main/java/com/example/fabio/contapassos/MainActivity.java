package com.example.fabio.contapassos;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

public class MainActivity extends AppCompatActivity {
    TextView pInicial, pFinal, contagem;
    Button iniciar;
    LocationManager location;
    private final int TASK_ADD_CODE = 23;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pInicial = (TextView) findViewById(R.id.locIni);
        pFinal = (TextView) findViewById(R.id.locFin);
        contagem = (TextView) findViewById(R.id.qtdPassos);
        iniciar = (Button) findViewById(R.id.button);
        iniciar.setOnClickListener(contadorListener);

        location = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

    }

    private View.OnClickListener contadorListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(!location.isProviderEnabled(LocationManager.GPS_PROVIDER)){
                Intent i = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(i);
            } else {
                Intent i = new Intent(MainActivity.this, Contador.class);
                startActivityForResult(i, TASK_ADD_CODE);
            }

        }
    };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode == TASK_ADD_CODE && resultCode == RESULT_OK) {
            //Location l = (Location) data.getSerializableExtra("local");
            String lInicio = (String) data.getSerializableExtra("localInicial");
            String lFim = (String) data.getSerializableExtra("localFinal");
            String quant = (String) data.getSerializableExtra("qtdePassos");
            //String coordenadas = "Latitude "+l.getLatitude()+"Longitude "+l.getLongitude();

            pInicial.setText(lInicio);
            pFinal.setText(lFim);
            contagem.setText(quant);

        }
    }
}
