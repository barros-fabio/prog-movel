package com.example.fabio.prova2parte2;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class GPS extends AppCompatActivity {
    ListView lista;
    Button start;
    ArrayAdapter<String> localsAdapter;
    ArrayList<String> localizacoes= new ArrayList<>();
    LocationManager location;
    ArrayList<Location> local = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gps);

        lista = (ListView) findViewById(R.id.listaLocal);
        start = (Button) findViewById(R.id.start);
        start.setOnClickListener(startListener);

        location = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
    }

    private View.OnClickListener startListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            location.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 1, locationListener);

        }
    };

    LocationListener locationListener = new LocationListener() {
        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }

        @Override
        public void onProviderEnabled(String provider) {
        }

        @Override
        public void onProviderDisabled(String provider) {
        }

        @Override
        public void onLocationChanged(Location location){
            DecimalFormat df = new DecimalFormat("#.0000");

            Location locationA = new Location("Ponto A");
            Location locationB = new Location("Ponto B");


            if(localizacoes.size()==0){ // Se fora primeira execução do programa, não existe a última localização
                if((location.getLatitude()>0)&&(location.getLongitude()>0)){ // Norte e Leste
                    Toast.makeText(GPS.this, "Você está a Norte do Equador e a Leste de Greenwich", Toast.LENGTH_SHORT).show();
                }else if((location.getLatitude()>0)&&(location.getLongitude()<0)){ // Sul e Leste
                    Toast.makeText(GPS.this, "Você está a Sul do Equador e a Leste de Greenwich", Toast.LENGTH_SHORT).show();
                }else if((location.getLatitude()<0)&&(location.getLongitude()<0)) { // Sul e Oeste
                    Toast.makeText(GPS.this, "Você está a Sul do Equador e a Oeste de Greenwich", Toast.LENGTH_SHORT).show();
                }else if((location.getLatitude()>0)&&(location.getLongitude()<0)) { // Norte e Oeste
                    Toast.makeText(GPS.this, "Você está a Sul do Equador e a Oeste de Greenwich", Toast.LENGTH_SHORT).show();
                }
                String fLat = df.format( location.getLatitude() );
                String fLong = df.format( location.getLongitude() );
                String coordenadas = "Latitude: " + fLat + "\nLongitude: " + fLong;

                Location l = new Location("Ponto");
                l.setLatitude(location.getLatitude());
                l.setLongitude(location.getLongitude());
                localizacoes.add(0,coordenadas);
                local.add(0,l);

                localsAdapter = new ArrayAdapter<String>(GPS.this, android.R.layout.simple_list_item_1, localizacoes);
                lista = (ListView) findViewById(R.id.listaLocal);
                lista.setAdapter(localsAdapter);
            }else{
                locationA.setLatitude(local.get(0).getLatitude()); // última posição adicionada no último update
                locationA.setLongitude(local.get(0).getLatitude()); // última posição adicionada no último update
                locationB.setLatitude(location.getLatitude());
                locationB.setLongitude(location.getLongitude());

                float distance = locationA.distanceTo(locationB);


                String fLat = df.format( location.getLatitude() );
                String fLong = df.format( location.getLongitude() );
                String coordenadas = "Latitude: " + fLat + "\nLongitude: " + fLong;



                localizacoes.add(0,coordenadas);

                Location l = new Location("ponto");
                l.setLatitude(location.getLatitude());
                l.setLongitude(location.getLongitude());
                local.add(0,l);


                localsAdapter = new ArrayAdapter<String>(GPS.this, android.R.layout.simple_list_item_1, localizacoes);
                lista = (ListView) findViewById(R.id.listaLocal);
                lista.setAdapter(localsAdapter);

                if((location.getLatitude()>0)&&(location.getLongitude()>0)){ // Norte e Leste
                    Toast.makeText(GPS.this, "Você está a Norte do Equador e a Leste de Greenwich, Distância andada "+distance+"", Toast.LENGTH_SHORT).show();
                }else if((location.getLatitude()>0)&&(location.getLongitude()<0)){ // Sul e Leste
                    Toast.makeText(GPS.this, "Você está a Sul do Equador e a Leste de Greenwich, Distância andada "+distance+"", Toast.LENGTH_SHORT).show();
                }else if((location.getLatitude()<0)&&(location.getLongitude()<0)) { // Sul e Oeste
                    Toast.makeText(GPS.this, "Você está a Sul do Equador e a Oeste de Greenwich, Distância andada "+distance+"", Toast.LENGTH_SHORT).show();
                }else if((location.getLatitude()>0)&&(location.getLongitude()<0)) { // Norte e Oeste
                    Toast.makeText(GPS.this, "Você está a Sul do Equador e a Oeste de Greenwich Distância andada "+distance+"", Toast.LENGTH_SHORT).show();
                }

            }

        }
    };
}
