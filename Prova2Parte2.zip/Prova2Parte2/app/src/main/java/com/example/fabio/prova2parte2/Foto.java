package com.example.fabio.prova2parte2;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;

public class Foto extends AppCompatActivity {
    Button fotografar;
    int numFoto;
    String nomeFoto;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foto);
        fotografar = (Button) findViewById(R.id.tirarFoto);
        fotografar.setOnClickListener(btFotografarListener);
    }
    private View.OnClickListener btFotografarListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT, getCaminhoArquivo());

            if(i.resolveActivity(Foto.this.getPackageManager()) != null) {
                startActivityForResult(i, 34);
            }
            else {
                Toast.makeText(Foto.this, "Não existe app para captura de imagem!", Toast.LENGTH_SHORT).show();
            }

        }
    };

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 34) {
            if (resultCode == RESULT_OK) {
                Uri takenPhotoUri = Uri.fromFile(new File(nomeFoto));
                Bitmap takenImage = BitmapFactory.decodeFile(takenPhotoUri.getPath());
                ImageView ivPreview = (ImageView) findViewById(R.id.fotografia);
                ivPreview.setImageBitmap(takenImage);
            }
        }
    }

    protected Uri getCaminhoArquivo() {
        File diretorioMidia = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "avaliacao02");

        if (!diretorioMidia.exists() && !diretorioMidia.mkdirs())
            Log.d("avaliacao02", "erro ao criar o arquivo!");

        numFoto++;
        String fileName = "foto" + numFoto + ".jpg";
        nomeFoto = diretorioMidia.getPath() + File.separator + fileName;

        return Uri.fromFile(new File(nomeFoto));
    }
}
