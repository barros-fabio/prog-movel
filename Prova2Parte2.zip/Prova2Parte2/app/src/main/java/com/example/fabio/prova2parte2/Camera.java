package com.example.fabio.prova2parte2;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Camera extends AppCompatActivity {
    Button tiraFoto, gravaVideo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);

        tiraFoto = (Button) findViewById(R.id.foto);
        gravaVideo = (Button) findViewById(R.id.gravar);
        tiraFoto.setOnClickListener(btFotoListener);
        gravaVideo.setOnClickListener(btVideoListener);

    }

    private View.OnClickListener btFotoListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent i = new Intent(Camera.this, Foto.class);
            startActivity(i);
        }
    };

    private View.OnClickListener btVideoListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent i = new Intent(Camera.this, Video.class);
            startActivity(i);
        }
    };




}
