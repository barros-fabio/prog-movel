package com.example.fabio.avaliacao1parte2;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

public class Questao6 extends AppCompatActivity {
    EditText userName, password;
    CheckBox administrator;
    Button btnSave;
    Boolean isAdmin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questao6);
        SharedPreferences preferences = getSharedPreferences("userinfo", Context.MODE_PRIVATE);

        userName = (EditText) findViewById(R.id.nomeUsuario);
        password = (EditText) findViewById(R.id.senhaUsuario);
        administrator = (CheckBox) findViewById(R.id.administradorCheck);
        btnSave = (Button) findViewById(R.id.button);

        btnSave.setOnClickListener(botaoSalvarListener);
        userName.setText(preferences.getString("username",""));
        password.setText(preferences.getString("password",""));

        // Checa se o usuário armazenado é administrador, caso haja
        if(preferences.getString("admin","false").equals("false"))
            isAdmin = false;
        else if(preferences.getString("admin","false").equals("true"))
            isAdmin = true;

        administrator.setChecked(isAdmin);
    }

    private View.OnClickListener botaoSalvarListener = new View.OnClickListener(){
        @Override
        public void onClick(View v){
            SharedPreferences preferences = getSharedPreferences("userinfo", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = preferences.edit();

            // Se existirem campos em branco, exibe alerta
            if((userName.getText().toString().equals(""))||(password.getText().toString().equals(""))){
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(Questao6.this);
                alertDialog.setTitle("Campos obrigatórios em branco");
                alertDialog.setMessage("Existem campos obrigatórios em branco!");
                alertDialog.setPositiveButton("OK",null);
                alertDialog.show();
            }else{
                // Checa se Usuário adminstrador está checado
                if(administrator.isChecked())
                    isAdmin = true;
                else
                    isAdmin = false;

                // coloca os dados no arquivo de preferências
                editor.putString("username",userName.getText().toString());
                editor.putString("password",password.getText().toString());
                editor.putString("admin",isAdmin.toString());
                editor.commit();

                //Encerra a atividade e volta para tela principal
                Questao6.this.finish();
            }

        }
    };
}
