package com.example.fabio.avaliacao1parte2;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class Questao7Select extends AppCompatActivity {
    String func;
    ArrayList<String> listaFuncionario = new ArrayList<String>();
    ArrayAdapter<String> funcionariosAdapter;
    ListView funcionariosListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questao7_select);

        DBHelper dbHelper = new DBHelper(Questao7Select.this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();




        Cursor cursor = db.rawQuery("SELECT * FROM Funcionario",null);
        cursor.moveToFirst();

        while(!cursor.isAfterLast()){

            String nome = cursor.getString(1);
            String sexo = cursor.getString(2);
            String categoria = cursor.getString(3);
            func = "\nNome do funcionário: "+ nome +"\nGênero: "+sexo+"\nCategoria: "+categoria;

            listaFuncionario.add(func);
            cursor.moveToNext();
        }

        funcionariosAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,listaFuncionario);
        funcionariosListView = (ListView) findViewById(R.id.listView);
        funcionariosListView.setAdapter(funcionariosAdapter);

        dbHelper.close();
    }
}
