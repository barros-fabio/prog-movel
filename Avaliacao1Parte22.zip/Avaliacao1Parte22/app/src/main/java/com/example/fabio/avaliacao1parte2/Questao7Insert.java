package com.example.fabio.avaliacao1parte2;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;

import java.util.ArrayList;

public class Questao7Insert extends AppCompatActivity {
    ArrayList<String> categoria = new ArrayList<>();
    Spinner cat;
    EditText nomeFunc;
    RadioButton btFem, btMasc;
    Button btnSalvar;
    String sexo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questao7_insert);

        nomeFunc = (EditText) findViewById(R.id.nomeFuncionario);
        btFem = (RadioButton) findViewById(R.id.btnFem);
        btMasc = (RadioButton) findViewById(R.id.btnMasc);
        btnSalvar = (Button) findViewById(R.id.salvarBotao);
        cat = (Spinner) findViewById(R.id.spinner);

        categoria.add("Junior");
        categoria.add("Pleno");
        categoria.add("Sênior");

        ArrayAdapter<String> opAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,categoria);
        cat.setAdapter(opAdapter);

        btnSalvar.setOnClickListener(btSalvarListener);

    }

    private View.OnClickListener btSalvarListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            DBHelper dbHelper = new DBHelper(Questao7Insert.this);
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            if(btFem.isChecked()){
                sexo= "Feminino";
            }else if(btMasc.isChecked()){
                sexo= "Masculino";
            }

            ContentValues values = new ContentValues();
            values.put("nome",nomeFunc.getText().toString());
            values.put("sexo",sexo);
            values.put("categoria",cat.getSelectedItem().toString());

            db.insert("Funcionario",null,values);
            dbHelper.close();

            Questao7Insert.this.finish();
        }
    };
}
