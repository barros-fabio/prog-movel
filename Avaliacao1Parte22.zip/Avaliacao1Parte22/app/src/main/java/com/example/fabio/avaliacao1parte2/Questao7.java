package com.example.fabio.avaliacao1parte2;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Questao7 extends AppCompatActivity {
    Button insert, select;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questao7);

        insert = (Button) findViewById(R.id.btnInsert);
        select = (Button) findViewById(R.id.btnSelect);

        insert.setOnClickListener(botaoInserirListener);
        select.setOnClickListener(botaoSelectListener);
    }

    private View.OnClickListener botaoInserirListener = new View.OnClickListener(){
        @Override
        public void onClick(View v){
            Intent i = new Intent(Questao7.this,Questao7Insert.class);
            startActivity(i);
        }
    };

    private View.OnClickListener botaoSelectListener = new View.OnClickListener(){
        @Override
        public void onClick(View v){
            Intent i = new Intent(Questao7.this,Questao7Select.class);
            startActivity(i);
        }
    };
}
